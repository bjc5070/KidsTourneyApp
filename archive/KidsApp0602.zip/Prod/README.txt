2016 BassCasters Kids Tournament App

This app can run completely offline through the google chrome browser.
Chrome version at the time of completion: 10/8.1/8/7 32-bit 

This app uses local storage and IndexedDB. The 'database' will persist only if using the same computer and browser.

**IMPORTANT**
Update Entry will over right entire database row. be sure to add all information for that contestant to perform the update.

Make sure all data is correct utilizing the 'display current database' button before running the sequence.